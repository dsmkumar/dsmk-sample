import { BadRequestException, Injectable, PipeTransform } from '@nestjs/common';

Injectable();
export class ValidatePayloadExistsPipe implements PipeTransform {
  transform(payload: any): any {
    if (
      !Object.keys(payload).length ||
      !Object.values(payload).some((item) => item !== '')
    ) {
      throw new BadRequestException('Payload should not be empty');
    }

    return payload;
  }
}
