export const Converter = (data: string, conversion: any) => {
    conversion.forEach((item) => {
        data = data.replace(new RegExp(`<${item.old}>`, 'g'), `<${item.new}>`);
        data = data.replace(new RegExp(`</${item.old}>`, 'g'), `</${item.new}>`);
        data = data.replace(new RegExp(`<${item.old}/>`, 'g'), `<${item.new}/>`);
    });
    return data;
};

export const convertJsonKeys = (data: any, conversion: any) => {
    let convertedData = JSON.stringify(data);
    conversion.forEach(element => {
        convertedData = convertedData.replace(new RegExp(`${element.old}`, 'g'), `${element.new}`);
    });   
    return JSON.parse(convertedData);
};
