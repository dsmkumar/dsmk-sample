const xml2js = require('xml2js');
import { NotFoundException } from '@nestjs/common';
import { parseBooleans } from 'xml2js/lib/processors.js';
export const parse = (
  response: string,
  serviceName: string,
  listName: string,
  recordName: string | null,
) => {
  const temp: any[] = [];
  xml2js.parseString(
    response,
    { explicitArray: false, valueProcessors: [parseBooleans] },
    function (err, result) {
      let data;
      if (recordName) {
        data = result[serviceName][listName][recordName];
      } else {
        data = result[serviceName][listName];
      }
      if (Array.isArray(data)) {
        data.forEach((item: any) => {
          temp.push(item);
        });
      } else {
        temp.push(data);
      }
    },
  );
  return JSON.parse(JSON.stringify(temp));
};

// for validations
export const parseValidation = (response: string, serviceName: string) => {
  const data: any[] = [];
  
  xml2js.parseString(
    response,
    { explicitArray: false, valueProcessors: [parseBooleans] },
    function (err, result) {
      // if there is any error in response from FEBA side
      const errortag = Object.keys(result);
      if (errortag[0] === 'ErrorResponse') {
        serviceName = 'ErrorResponse';
      }

      if (!response) {
        throw new NotFoundException('Error in Response');
      } else {
        result = result[serviceName];

        const arrayVal = result['hd:header']['hd:STATUS']['hd:MESSAGE'];

        if (!arrayVal.length) {
          const responseStatus = {
            statusCode:
              result['hd:header']['hd:STATUS']['hd:MESSAGE']['hd:MESSAGE_CODE'],
            statusMessage:
              result['hd:header']['hd:STATUS']['hd:MESSAGE']['hd:MESSAGE_DESC'],
            statusType:
              result['hd:header']['hd:STATUS']['hd:MESSAGE']['hd:MESSAGE_TYPE'],
          };
          data.push(responseStatus);
        } else {
          const responseStatus = {
            statusCode:
              result['hd:header']['hd:STATUS']['hd:MESSAGE'][
                arrayVal.length - 1
              ]['hd:MESSAGE_CODE'],
            statusMessage:
              result['hd:header']['hd:STATUS']['hd:MESSAGE'][
                arrayVal.length - 1
              ]['hd:MESSAGE_DESC'],
            statusType:
              result['hd:header']['hd:STATUS']['hd:MESSAGE'][
                arrayVal.length - 1
              ]['hd:MESSAGE_TYPE'],
          };
          data.push(responseStatus);
        }
      }
    },
  );


    return data;
};
