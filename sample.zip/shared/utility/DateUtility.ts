import * as moment from 'moment';
export const getCurrentDateTimeIST = () => {

    return moment(new Date()).utcOffset("+05:30")
}

export const isInISTTimeZone = () => {
    return -(new Date().getTimezoneOffset() / 60) == 5.5;
}