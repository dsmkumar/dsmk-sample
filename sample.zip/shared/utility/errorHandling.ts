import axios from 'axios';

import { HTTPMethods } from '../../shared/constant'
import { LoggerService } from './logger/logger.service';


let logger: LoggerService = new LoggerService('api-error-handle');

function handleDEHError(err: any,correlationId?:string) {
    let status = err?.response?.status +'';
    let res;
    logger.log(correlationId,"Status of API call:", status);
    switch(status){
        case "400": res = {response:[],resCode:"400",resMessage:"Bad Request",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"API failed with response code 400",'');
                    break;
        case "401": res =  {response:[],resCode:"401",resMessage:"Unauthorized",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"API failed with response code 401",'');
                    break;
        case "404": res =  {response:[],resCode:"404",resMessage:"Resource Not Found",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"API failed with response code 404",'');
                    break;
        case "500": res =  {response:[],resCode:"500",resMessage:"Internal Server Error",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"API failed with response code 500",'');
                    break;
        case "504": res =  {response:[],resCode:"504",resMessage:"Timeout Occured",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"API failed with response code 504",'');
                    break;
        case "503": res =  {response:[],resCode:"503",resMessage:"Service Unavailable",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"API failed with response code 503",'');
                    break;
        case "502": res =  {response:[],resCode:"502",resMessage:"Bad Gateway",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"API failed with response code 502",'');
                    break;
        default: res = {response:[],resCode:status,resMessage:"Some Error Occured",channelContext:err?.response?.headers?.channelcontext, resStatus: res.status}
                    logger.error(correlationId,"Unknown error occured  with status code: ", status);
                    break;
    }   
    return res;
}

export async function apiCallUtil(reqObj:{url:string,options:any, method:HTTPMethods, body?:any, timeout?:number,correlationId?:any}){
       let apiRes;
       let timeout = reqObj?.timeout || 60000;
    switch(reqObj.method){
        case HTTPMethods.DELETE:
        case HTTPMethods.GET: 
        case HTTPMethods.PUT:
        case HTTPMethods.POST: apiRes = await callAPI(reqObj.url,reqObj.options,timeout,reqObj.method,reqObj?.body,reqObj?.correlationId);
                    break;
        default: apiRes = {response:[],resCode:"400",resMessage:"Bad Request",channelContext:null}
                 logger.log(reqObj?.correlationId,"Wrong HTTP Method Passed");
    }
    return apiRes;

}

async function callAPI(url, options,timeout,method,body?:any,correlationId?:any){
    
    let obj = {
        url:url,
        headers:options.headers,
        timeout:timeout,
        method:method,
        httpsAgent: options.httpsAgent
    };
    let apiResponse:any;
    if(method == HTTPMethods.POST || method == HTTPMethods.PUT){
        obj['data'] = body
    }
    await axios(obj).then(res=>{ 
       logger.log(correlationId,"Request Processed Successfully ");
    apiResponse = {response:res.data,resCode:"200",resMessage:"Request Processed Successfully",channelContext:res?.headers?.channelcontext, resStatus: res.status}
    }).catch(err=>{
        logger.error(correlationId,"Error hitting API, url: "+ url +" Error: ",err);
        logger.error(correlationId,"Channel Context: ",err?.response?.headers?.channelcontext);
        apiResponse = handleDEHError(err,correlationId)
        
    })

    return apiResponse;
}

