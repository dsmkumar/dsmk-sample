import { Catch, RpcExceptionFilter, ArgumentsHost, ExceptionFilter } from '@nestjs/common';
import { Observable, throwError } from 'rxjs';
import { RpcException } from '@nestjs/microservices';
import { LoggerService } from '../../shared/utility/logger/logger.service';
// import { UserBusinessErrors } from '../errors/user-business.error';

@Catch(RpcException)
export class GrpcExceptionFilter implements ExceptionFilter {
  // private readonly logger: LoggerService = new LoggerService(
  //   GrpcExceptionFilter.name,
  // );
  private logger: LoggerService = new LoggerService('shared-rpc-exception-filter');
  

  catch(exception: RpcException, host: ArgumentsHost): Observable<any> {
    // const logMessage = exception.getError();
    // If an unfamiliar error occurs / not a business error
    this.logger.log(exception)
    // if (
    //   Object.values(UserBusinessErrors).includes(logMessage['error']) == false
    // ) {
    //   this.logger.error(correlationId,JSON.stringify(exception.getError()), exception.stack);
    // }
    return throwError(exception.getError());
  }
}
