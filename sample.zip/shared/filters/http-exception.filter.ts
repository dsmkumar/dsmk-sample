import { ExceptionFilter, Catch, ArgumentsHost } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { LoggerService } from 'shared/utility/logger/logger.service';

interface Response {
  message: string;
  code: string;
  errorCode?: string;
}
@Catch(RpcException)
export class HttpExceptionFilter implements ExceptionFilter {
  private logger: LoggerService = new LoggerService(
    'shared-http-exception-filter',
  );

  catch(exception: RpcException, host: ArgumentsHost) {
    const err = exception.getError();
    const ctx = host.switchToHttp();
    const response: any = ctx.getResponse<Response>();
    this.logger.log(err['details']);
    if (err?.['details'] && err['details']?.includes('::')) {
      const [code, message, errorCode] = err['details'].split('::');
      response.statusCode = code;
      const res: Response = {
        code,
        message,
        errorCode,
      };
      response.json(res);
    } else {
      response.statusCode = 500;
      response.json({
        code: 500,
        message: 'Internal server error',
      });
    }
  }
}
