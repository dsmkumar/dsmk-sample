export const fileTypesConfig = {
  pdf: {
    contentType: 'application/pdf',
    ext: 'pdf',
  },
  csv: {
    contentType: 'text/csv',
    ext: 'csv',
  },
  xls: {
    contentType:
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ext: 'xlsx',
  },
  txt: {
    contentType: 'text/plain',
    ext: 'txt',
  },
  xml: {
    contentType: 'text/xml',
    ext: 'xml',
  },
  xlsx: {
    contentType:
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ext: 'xlsx',
  },
  MT940: {
    contentType: 'text/plain',
    ext: 'MT940',
  },
  zip: {
    contentType: 'application/zip',
    ext: 'zip',
  },
  jpg: {
    contentType: 'application/jpg',
    ext: 'jpg',
  },
  jpeg: {
    contentType: 'application/jpeg',
    ext: 'jpeg',
  },
  png: {
    contentType: 'application/png',
    ext: 'png',
  },
};

export const positivePaynotification = {
  notificationCategoryGeneral: 'General',
  notificationCategoryAlerts: 'Alerts',
};

export const recentActivityConstants = {
  status: {
    success: 'AAC',
  },
};

export const environment = {
  prod: 'production',
};

export const otpDailyLimit =
  'You have exhausted the daily limit for OTP validation attempts. Please try logging in tomorrow';
export const loginDailyLimit =
  'You have exhausted the daily limit for Login attempts. Please try logging in tomorrow';
export const transactionPasswordExpired =
  'Transaction Password has been expired. Kindly Reset your Password';
export const signOnPasswordExpired =
  '{"message_TYPE":"CDP","messageDesc":"Signon Password has been expired. Kindly Reset your Password","messageAddlnInfo":"Authentication Not Successful","messageCode":"00101","nameSpaceInfo":"PROD","validationError":"Your password has expired. To reset password,"}';

export const loginFirstToGenerateAccessToken =
  'Kindly Login First or provide Password';
export const userAddedOnActivateAccount = 'User Added Successfully';
export const userUpdatedOnActivateAccount = 'User updated Successfully';
export const userSetNewPasswordOnActivateAccount =
  'User has set new password successfully';
export const alreadySetPasswordForActivateAccount =
  'You have already set your password. Please Login  with new credential';
export const otpLockMessage =
  'OTP is locked due to 3 unsuccessful OTP attempts. Please try again on the next calendar date.';
export const genericErrorMessage = {
  message_TYPE: 'BE',
  messageCode: '00103',
  messageDesc: 'Something went wrong',
  messageAddlnInfo: 'Something went wrong',
};
export const userNotFoundErrorMessage = {
  message_TYPE: 'BE',
  messageCode: '00104',
  messageDesc: 'Invalid credentials entered',
  messageAddlnInfo: 'User Not found',
};
export const ifscConstants = {
  true: 'true',
  parentBankCode: 'UTIB',
};

export const positivePayReportConstants = {
  templateName: 'Default',
  fileNotFound: 'ENOENT',
  dataInserted: 'Data inserted',
  createdOn: 'createdOn',
  pdfCorporateLabel: 'Corporate Name : ',
  reportLabel: 'Report : ',
  fromDateLabel: 'From Date : ',
  toDateLabel: 'To Date : ',
  pp_report: 'Positive Pay Report',
  corporateLabel: 'Corporate : ',
  dateLabel: 'Report Date : ',
  customerId: 'Customer ID:',
  customerName: 'Customer Name:',
  date: ['createdOn', 'chequeDate'],
  reportsDateFormat: 'DD-MM-YYYY',
  reportsDateDisplayFormat: 'DD-MM-YYYY HH:MM:SS',
  serviceRequestSummary: 'ServiceRequestSummary',
  reportType: {
    pp: 'positive_pay',
  },
  reportDisplayName: {
    positive_pay: 'Positive Pay Report',
  },
};
export const commonErrorMsgForFailed =
  'Something went wrong, please try again.';
export const invalidDownloadFileFormat = 'Invalid file format or action type!';

export const esbErrorCodes = {
  400: { code: 400, message: 'NO DATA FOUND' },
  801: {
    code: 400,
    message: 'ConversionException! Unable To Process The Request',
  },
  802: { code: 400, message: 'ParserException! Invalid Message Format.' },
  803: { code: 400, message: 'CastException! Unable To Process The Request' },
  804: { code: 400, message: 'Error in Encryption and Decryption' },
  805: {
    code: 400,
    message: 'SecurityException! Unable To Process The Request',
  },
  806: {
    code: 400,
    message: 'UNAUTHORIZED! Access to this service is restricted',
  },
  807: {
    code: 502,
    message:
      'DatabaseException! Unable To Process The Request Due to Database Exception',
  },
  808: {
    code: 500,
    message: 'MessageException! Unable To Process The Request',
  },
  809: {
    code: 502,
    message:
      'SqlException! Unable To Process The Request Due to Database Exception',
  },

  810: { code: 502, message: 'SocketException! Unable To Process The Request' },
  811: { code: 500, message: 'FatalException! Unable To Process The Request' },
  812: {
    code: 500,
    message: 'ConfigurationException! Unable To Process The Request',
  },
  813: {
    code: 500,
    message: 'UnknownException! Unable To Process The Request',
  },
  814: { code: 500, message: 'Unable To Process The Request' },
  815: {
    code: 504,
    message: 'SocketTimeoutException! Unable To Process The Request',
  },
  816: { code: 400, message: 'Invalid Header details' },
  817: {
    code: 400,
    message: 'ChannelId Not Present - Error In Request Decryption',
  },
  818: { code: 400, message: 'Invalid/Unsafe Message' },
};

export const prodPhantomPath = '/usr/local/bin/phantomjs';

export const pdfconstant = {
  date1: '01-01-2022',
  date2: '31-01-2022',
  amount: '0 - 10,000,000.00',
  ccypair: 'USD/INR',
  dealStatus: 'Sucess',
  contraAmount: '0 - 10,000,000.00',
  titleText: 'FX Transaction History',
  endText: '++++ End of Statement ++++',
  customerName: 'Customer Name:',
  customerID: 'Customer ID:',
  accountNumber: 'Account Number:',
  acmeCorpPvtLtd: 'Acme Corp Pvt Ltd',
  CUST3432543: 'CUST3432543',
  id: '23432543654667',
  portrait: 'portrait',
  landscape: 'landscape',
  notes: 'Note:',
  description:
    'Unless the constituent notifies the bank immediately of any discrepancy found by him/her in this statement of account, ',
  descriptionLandscape:
    'Unless the constituent notifies the bank immediately of any discrepancy found by him/her in this statement of account, it will be taken that he/she has found statement correct.',
  foundStateText: 'it will be taken that he/she has found statement correct.',
  contactWithTreasuryManager:
    'For any other discrepancies, please contact your Treasury Relationship Manager.',
  generatedText:
    'This is a system generated output and is not required to be signed by any officials of the Bank.',
  bottomText:
    'Save Paper | Save Trees, Please consider the environment before printing, unless you really need to.',
  statementPeriod: 'Statement of LBLTEXT for Period From:',
  filterBy: 'Filtered by :-',
  amountText: 'Amount: ',
  ccYPairText: 'CCY Pair:',
  dealStatusText: 'Deal Status:',
  contraAmountText: 'Contra Amount:',
  reportPeriod: 'LBLTEXT for Period From:',
  accStmtReportPeriod: 'Statement of Account No - LBLTEXT for period From:',
};

export const sanitizeStatus = {
  pending: 'Pending',
  'self-approved': 'Self Approved',
  rejected: 'Rejected',
  'referred-back': 'Referred Back',
  approved: 'Approved',
  'in-process': 'In Process',
  'pending-with-bank': 'Pending with Bank',
  'rejected-by-bank': 'Rejected by Bank',
  'partial-amount-processed': 'Partial Amount Processed',
  failed: 'Failed',
  expired: 'Expired',
};

export const statutoryTransactionLabels = {
  TXN_INITIATION_DATE: 'TXN Initiation date',
  refId: 'Reference ID',
  paymentType: 'Payment Type',
  requestedBy: 'Requested by',
  requestedDate: 'Request Date',
  debitAccount: 'Debit Account',
  amount: 'Amount',
  month: 'Month',
  trrn: 'TRRN',
  challanExpDate: 'Challan Expiry Date',
  challanType: 'Challan Type',
  status: 'Status',
  acc1: 'Account 1',
  acc2: 'Account 2',
  acc10: 'Account 10',
  acc21: 'Account 21',
  acc22: 'Account 22',
  challanNumber: 'Challan Number',
  partyCode: 'Party Code',
  customerName: 'Customer Name',
  processedDate: 'Proccessed date',
  requestBy: 'Requested by',
  requestDate: 'Requested date',
  gstin: 'GSTIN',
  state: 'State',
  igstAmount: 'Igst Amount',
  sgstAmount: 'Sgst Amount',
  cgstAmount: 'Cgst Amount',
  cessAmount: 'Cess Amount',
  remarks: 'Remarks',
  cpin: 'CPIN',
  crn: 'CRN',
  challanInitiationDate: 'Challan initiation Date',
  txnInitiationDate: 'Transaction Date',
  initiatorName: 'Initator Name',
  approver1: 'Approver 1',
  approver2: 'Approver 2',
  verifiedBy: 'Verified By',
  confirmedBy: 'Confirmed By',
  paymentMethod: 'Payment Method',
  challanExpiryDate: 'Challan Expiry Date',
};
export const GENERAL_RULE_DETAILS = ['GEN', 'GENERAL'];

export const beneCheckerLabels = {
  srNo: 'Sr No',
  beneAccountName: 'Beneficiary Name',
  beneCode: 'Beneficiary code',
  requestedBy: 'Requested name',
  requestedDate: 'Requested date',
  requestType: 'Request type',
  beneAccountType: 'Account type',
  beneBranch: 'Beneficiary branch',
  beneAccountNumber: 'Beneficiary account number',
  ifsc: 'IFSC',
  beneBank: 'Beneficiary bank',
  previousApprover: 'Last approver',
  nextApprover: 'Next approver',
  action: 'Action',
  status: 'Status',
};

export const vendorCheckerLabels = {
  srNo: 'Sr No',
  txnType: 'Transaction type',
  beneCode: 'Beneficiary code',
  beneName: 'Beneficiary Name',
  beneAccountNumber: 'Beneficiary account number',
  amount: 'Amount',
  ifsc: 'IFSC',
  beneBank: 'Beneficiary bank',
  debitAccountNumber: 'Debit account number',
  debitAccountBalance: 'Debit account balance',
  paymentMode: 'Payment mode',
  crn: 'CRN',
  paymentDate: 'Payment date',
  paymentType: 'Payment type',
  lastApprover: 'Last approver',
  nextApprover: 'Next approver',
  frequency: 'Frequency',
  installments: 'Instalments',
  accountType: 'Account type',
  action: 'Action',
  status: 'Status',
};

export enum HTTPMethods {
  'GET' = 'get',
  'POST' = 'post',
  'PUT' = 'put',
  'DELETE' = 'delete',
}

export const USER_ROLES = {
  TFIN: 'TFIN',
  ONLYPAY: 'ONLYPAY',
  TAXSP: 'TAXSP',
  AUPLOAD: 'AUPLOAD',
  EUPLOAD: 'EUPLOAD',
  CUSER: 'CUSER',
  IUSER: 'IUSER',
  RESENT: 'RESENT',
  SLDDENT: 'SLDDENT',
  SLDDEA: 'SLDDEA',
  SLDDAPP: 'SLDDAPP',
  ENTERER: 'ENTERER',
  ENTAPP: 'ENTAPP',
  APPROVER: 'APPROVER',
  TAXENT: 'TAXENT',
  TAXEA: 'TAXEA',
  TAXAPP: 'TAXAPP',
  EXTENT: 'EXTENT',
  EXTEA: 'EXTEA',
  EXTAPR: 'EXTAPR',
  ENTAPPENTERER: 'ENTAPP-ENTERER',
  ENTAPPAPPROVER: 'ENTAPP-APPROVER',
  ENTRPA: 'ENTRPA',
};

export const USER_TYPES = {
  ONEGEN: 'onegen',
  MAKER: 'maker',
  CHECKER: 'checker',
};

export const USER_INFO = {
  [USER_ROLES.TFIN]: { USER_TYPE: USER_TYPES.CHECKER },
  [USER_ROLES.ONLYPAY]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.TAXSP]: { USER_TYPE: USER_TYPES.CHECKER },
  [USER_ROLES.AUPLOAD]: { USER_TYPE: USER_TYPES.CHECKER },
  [USER_ROLES.CUSER]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.IUSER]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.RESENT]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.SLDDENT]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.SLDDEA]: { USER_TYPE: USER_TYPES.ONEGEN },
  [USER_ROLES.SLDDAPP]: { USER_TYPE: USER_TYPES.CHECKER },
  [USER_ROLES.ENTERER]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.ENTAPP]: { USER_TYPE: USER_TYPES.ONEGEN },
  [USER_ROLES.APPROVER]: { USER_TYPE: USER_TYPES.CHECKER },
  [USER_ROLES.TAXENT]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.TAXEA]: { USER_TYPE: USER_TYPES.ONEGEN },
  [USER_ROLES.TAXAPP]: { USER_TYPE: USER_TYPES.CHECKER },
  [USER_ROLES.EXTENT]: { USER_TYPE: USER_TYPES.MAKER },
  [USER_ROLES.EXTEA]: { USER_TYPE: USER_TYPES.ONEGEN },
  [USER_ROLES.EXTAPR]: { USER_TYPE: USER_TYPES.CHECKER },
  // TODO : Need to check USERTYPE for ENTAPP Role
  [USER_ROLES.ENTAPPENTERER]: { USER_TYPE: USER_TYPES.ONEGEN },
  [USER_ROLES.ENTAPPAPPROVER]: { USER_TYPE: USER_TYPES.ONEGEN },
};

export const gstinMasterCheckerLabels = {
  srNo: 'Sr No',
  gstin: 'GSTIN',
  state: 'State',
  registrationName: 'Company',
  pan: 'PAN',
  requestDate: 'Requested Date',
  requestType: 'Request Type',
  remarks: 'Remarks',
  status: 'Status',
};

export const gstinCheckerLabels = {
  requestedDate: 'Requested date',
  gstn: 'GSTIN',
  state: 'State',
  regName: 'Company',
  pan: 'PAN',
  requestedBy: 'Requested by',
  approvers: 'Approvers',
  status: 'Status',
  remarks: 'Remarks',
};
