import { EntityRepository, Repository, Between } from 'typeorm';
import { Aggregator } from '../entities/aggregator.entity';
import { LoggerService } from '../../../../shared/utility/logger/logger.service';
import {
  AddAggregatorRequestDto,
  DeleteAggregatorRequestDto,
  GetAggreagatorRequestDto,
} from '../dto/aggregator.dto';
import { RpcException } from '@nestjs/microservices';
import * as moment from 'moment';
@EntityRepository(Aggregator)
export class AggregatorRepository extends Repository<Aggregator> {
  private logger: LoggerService = new LoggerService('aggregator-repository');
  async addAggregator(addAggregatorRequestDto: AddAggregatorRequestDto) {
    try {
      const { name, code, callback_url } = addAggregatorRequestDto;
      const aggregator: any = {
        name: name,
        code: code,
        callback_url: callback_url,
        created_on: moment(new Date()),
      };
      return await this.save(aggregator);
    } catch (error) {
      this.logger.error(
        addAggregatorRequestDto['correlationId'],
        'Error in database operations',
        error,
      );
      throw new RpcException(error);
    }
  }
  async deleteAggregator(
    deleteAggregatorRequestDto: DeleteAggregatorRequestDto,
  ) {
    const { id } = deleteAggregatorRequestDto;
    try {
      const result = await this.delete({
        id: id,
      });
      if (result.affected === 0) {
        throw new RpcException('400::Record Not found');
      }
      return result;
    } catch (error) {
      this.logger.error(
        deleteAggregatorRequestDto['correlationId'],
        'Error in deleteAggregator method :',
        error,
      );
      throw new RpcException(error);
    }
  }

  async getAggregators(): Promise<Aggregator[]> {
    const filter = {};
    return this.find(filter);
  }

  async getAggregatorById(
    getAggreagatorRequestDto: GetAggreagatorRequestDto,
  ): Promise<Aggregator[]> {
    const { id } = getAggreagatorRequestDto;
    return this.find({ id: id });
  }

  async updateAggregator(filter, update): Promise<any> {
    update.modified_on = moment(new Date());
    return this.update(filter, update);
  }
}
