import { Module } from '@nestjs/common';
import { OnboardController } from './onboard.controller';
import { OnboardService } from './onboard.service';
import { AggregatorRepository } from './repositories/aggregator.repository';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ScheduleModule } from '@nestjs/schedule';
import { QueuecallsService } from 'apps/coc-client-gateway/src/queueCalls.service';
import { BullModule } from '@nestjs/bull';

const redisConfigData = configService => ({
  host: configService.get('REDIS_HOST'),
  port: +configService.get('REDIS_PORT'),
});
@Module({
  imports: [
    ScheduleModule.forRoot(),
    ConfigModule.forRoot({
      envFilePath: ['.env'],
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => {
        const isProd = configService.get('NODE_ENV') === 'production';
        return {
          ssl: isProd,
          extra: {
            ssl: isProd ? { rejectUnauthorized: false } : null,
          },
          type: 'postgres',
          host: configService.get('DB_HOST'),
          port: configService.get('DB_PORT'),
          username: configService.get('DB_USERNAME'),
          password: configService.get('DB_PASSWORD'),
          database: configService.get('DB_DATABASE'),
          autoLoadEntities: true,
          synchronize: true,
        };
      },
    }),
    TypeOrmModule.forFeature([AggregatorRepository]),
    BullModule.registerQueueAsync({
      name: 'downstream_logs',
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        redis: redisConfigData(configService),
        defaultJobOptions: {
          removeOnComplete: true,
          removeOnFail: true,
        },
      }),
      inject: [ConfigService],
    }),
    ConfigService,
  ],
  controllers: [OnboardController],
  providers: [OnboardService, QueuecallsService],
})
export class OnboardModule {}
