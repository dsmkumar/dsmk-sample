export class AddAggregatorRequestDto {
  name: string;
  code: string;
  callback_url: string;
}
export class UpdateAggregatorRequestDto {
  name: string;
  code: string;
  callback_url: string;
  id: string;
}
export class DeleteAggregatorRequestDto {
  id: string;
}
export class GetAggreagatorRequestDto {
  id: string;
}
