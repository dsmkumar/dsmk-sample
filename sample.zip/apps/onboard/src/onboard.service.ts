import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { InjectRepository } from '@nestjs/typeorm';
import { LoggerService } from '../../../shared/utility/logger/logger.service';
import {
  AddAggregatorRequestDto,
  DeleteAggregatorRequestDto,
  UpdateAggregatorRequestDto,
  GetAggreagatorRequestDto,
} from './dto/aggregator.dto';
import { AggregatorRepository } from './repositories/aggregator.repository';

const _ = require('lodash');

@Injectable()
export class OnboardService {
  private logger: LoggerService = new LoggerService('onboard-service');

  constructor(
    @InjectRepository(AggregatorRepository)
    private aggregatorRepository: AggregatorRepository,
  ) {}

  getHello(): { entityName: string } {
    return { entityName: 'Hello World!' };
  }

  async getAggregators() {
    const res = await this.aggregatorRepository.getAggregators();
    if (res) {
      return { status: 200, message: 'Success', data: res };
    } else {
      return { status: 500, message: 'Failed' };
    }
  }

  async getAggregatorById(getAggreagatorRequestDto: GetAggreagatorRequestDto) {
    const res = await this.aggregatorRepository.getAggregatorById(
      getAggreagatorRequestDto,
    );
    console.log(res);
    if (res && res[0]) {
      return { status: 200, message: 'Success', data: res[0] };
    } else {
      return { status: 500, message: 'Failed' };
    }
  }

  async addAggregator(addAggregatorRequestDto: AddAggregatorRequestDto) {
    try {
      const res = await this.aggregatorRepository.addAggregator(
        addAggregatorRequestDto,
      );
      if (res) {
        return { status: 200, message: 'Success' };
      } else {
        return { status: 500, message: 'Failed' };
      }
    } catch (e) {
      console.log(e);
      return { status: 500, message: 'Failed' };
    }
  }

  async updateAggregator(
    updateAggregatorRequestDto: UpdateAggregatorRequestDto,
  ) {
    const res = await this.aggregatorRepository.updateAggregator(
      { id: updateAggregatorRequestDto.id },
      updateAggregatorRequestDto,
    );
    console.log('res', res);
    if (res && res.affected) {
      return { status: 200, message: 'Success' };
    } else {
      return { status: 500, message: 'Failed' };
    }
  }

  async deleteAggregator(
    deleteAggregatorRequestDto: DeleteAggregatorRequestDto,
  ) {
    const res = await this.aggregatorRepository.deleteAggregator(
      deleteAggregatorRequestDto,
    );
    if (res) {
      return { status: 200, message: 'Success' };
    } else {
      return { status: 500, message: 'Failed' };
    }
  }
}
