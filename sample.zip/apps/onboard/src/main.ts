import { NestFactory } from '@nestjs/core';
import { OnboardModule } from './onboard.module';
import { MicroserviceOptions } from '@nestjs/microservices';
import { MicroservicesOptions } from './config/microservice.config';

async function bootstrap() {
  const app = await NestFactory.createMicroservice<MicroserviceOptions>(
    OnboardModule,
    process.env.NODE_ENV == 'production'
      ? MicroservicesOptions({ url: `0.0.0.0:${process.env.OMS_PORT}` })
      : MicroservicesOptions({ url: process.env.OMS_SRV_URL }),
  );
  app.listen(() => console.log('Onboard Microservice is running'));

  app.enableShutdownHooks();

  process.on('SIGTERM', () => {
    console.info('SIGTERM signal received.');
    console.log('Closing http server.');
    // server.close(() => {
    //   console.log('Http server closed.')
    // });
  });
}
bootstrap();
