import { Transport, MicroserviceOptions } from '@nestjs/microservices';
import { join } from 'path';
import { NestMicroserviceOptions } from '@nestjs/common/interfaces/microservices/nest-microservice-options.interface';
export const microserviceOptions: MicroserviceOptions &
  NestMicroserviceOptions = {
  transport: Transport.GRPC,
  options: {
    package: 'oms',
    protoPath: join(__dirname, '../../apps/onboard/proto/oms.proto'),
    url: process.env.OMS_SRV_URL,
    loader: { keepCase: true, arrays: true, objects: true },
  },
};

export const MicroservicesOptions = (
  msOptions?,
): MicroserviceOptions & NestMicroserviceOptions => ({
  transport: Transport.GRPC,
  options: {
    package: 'oms',
    protoPath: join(__dirname, '../../apps/onboard/proto/oms.proto'),
    url: msOptions.url,
    loader: { keepCase: true, arrays: true, objects: true },
  },
});
