import { Body, Controller } from '@nestjs/common';
import { GrpcMethod } from '@nestjs/microservices';
import { OnboardService } from './onboard.service';
import {
  AddAggregatorRequestDto,
  DeleteAggregatorRequestDto,
  UpdateAggregatorRequestDto,
  GetAggreagatorRequestDto,
} from './dto/aggregator.dto';

@Controller()
export class OnboardController {
  constructor(private readonly onboardService: OnboardService) {}

  @GrpcMethod('OmsService', 'getHello')
  async getHello() {
    console.log('cma e her');
    return this.onboardService.getHello();
  }

  @GrpcMethod('OmsService', 'getAggregators')
  async getAggregators() {
    console.log('cma e her');
    return this.onboardService.getAggregators();
  }

  @GrpcMethod('OmsService', 'getAggregatorById')
  async getAggregatorById(getAggreagatorRequestDto: GetAggreagatorRequestDto) {
    console.log('cma e her', getAggreagatorRequestDto);
    return this.onboardService.getAggregatorById(getAggreagatorRequestDto);
  }

  @GrpcMethod('OmsService', 'addAggregator')
  async addAggregator(addAggregatorRequestDto: AddAggregatorRequestDto) {
    console.log('cma e her', addAggregatorRequestDto);
    return this.onboardService.addAggregator(addAggregatorRequestDto);
  }

  @GrpcMethod('OmsService', 'updateAggregator')
  async updateAggregator(
    updateAggregatorRequestDto: UpdateAggregatorRequestDto,
  ) {
    console.log('cma e her');
    return this.onboardService.updateAggregator(updateAggregatorRequestDto);
  }

  @GrpcMethod('OmsService', 'deleteAggregator')
  async deleteAggregator(
    deleteAggregatorRequestDto: DeleteAggregatorRequestDto,
  ) {
    console.log('cma e her');
    return this.onboardService.deleteAggregator(deleteAggregatorRequestDto);
  }
}
