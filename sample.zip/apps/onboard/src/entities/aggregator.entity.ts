import { Column, Entity, PrimaryGeneratedColumn, Unique } from 'typeorm';
@Entity()
export class Aggregator {
  @PrimaryGeneratedColumn('uuid')
  id: string;
  @Column()
  name: string;
  @Column()
  code: string;
  @Column({ nullable: true })
  callback_url: string;
  @Column({ type: 'timestamptz', nullable: true })
  created_on: string;
  @Column({ type: 'timestamptz', nullable: true })
  modified_on: string;
}
