export const accountOverviewMockResponse = {
    "response": {
        "header": {
            "subHeader": {
                "requestUUID": "SB0521147",
                "serviceRequestId": "AE.ARD.C24.JSON.001",
                "serviceRequestVersion": "1.0",
                "channelId": "SAK"
            }
        },
        "body": {
            "getAccountDetailsResponse": {
                "responseBody": {
                    "valueDate": "2015-05-07",
                    "accountCurrency": "INR",
                    "accountDetail": {
                        "accountId": "918050061049395",
                        "accountBalance": [
                            {
                                "balanceType": "LEDGER BALANCE",
                                "balanceAmount": {
                                    "amountValue": 1000000,
                                    "currencyCode": "INR"
                                }
                            },
                            {
                                "balanceType": "AVAILABLE BALANCE",
                                "balanceAmount": {
                                    "amountValue": 1000000,
                                    "currencyCode": "INR"
                                }
                            },
                            {
                                "balanceType": "FBAT BALANCE",
                                "balanceAmount": {
                                    "amountValue": 0,
                                    "currencyCode": "INR"
                                }
                            },
                            {
                                "balanceType": "FFD BALANCE",
                                "balanceAmount": {
                                    "amountValue": 0,
                                    "currencyCode": "INR"
                                }
                            },
                            {
                                "balanceType": "USERDEFINED BALANCE",
                                "balanceAmount": {
                                    "amountValue": 0,
                                    "currencyCode": "INR"
                                }
                            }
                        ],
                        "accountType": "TDA",
                        "schemeCode": "RDST",
                        "openDate": "20180702",
                        "accountStatus": "A",
                        "closeDate": "",
                        "ledgerBalance": 1000000,
                        "accountName": "AKRAS SIOY HEGPEE IA KNAS AIRBD NAHEIUAS",
                        "accountManagerName": "",
                        "interestRate": 8,
                        "maturityAmount": 20385800,
                        "depositAmount": 500000,
                        "loanAccounttNumber": "",
                        "loanAccountCurrenncy": "",
                        "repaymentAccountNumber": "004010100672993",
                        "repaymentAccontCurrency": "INR",
                        "maturityDate": "20210702",
                        "accoungtCloseValueDate": "",
                        "depositPeriodMonthsComponent": 36,
                        "depositPeriodDaysComponent": 0,
                        "depositStatus": "N",
                        "autoRenewalStatus": "N",
                        "autoCloseFlag": true,
                        "staffFlag": true,
                        "limitexpirydate":"19991130"
                    },
                    "status": "000"
                }
            }
        }
    }
}