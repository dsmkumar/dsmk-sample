export const swagger = {
  getCustomerId: {
    summary: 'Get customer Id, PAN and default rule (Gateway)',
    description:
      'In request body client need to pass corporate Id for which api will give a response back with customer Id, pan and default rule associated with that corporate Id',
  },
  viewChallan: {
    summary: 'Get list of Challan (Gateway)',
    description: 'Get list of Challan',
  },
  deleteChallan: {
    summary: 'Delete GST epayment challan (Gateway)',
    description: 'Delete GST epayment challan',
  },
  addChallan: {
    summary: 'Add challan (Gateway)',
    description:
      'Add challan to master table when user returns from gst portal after creation of challan',
  },
  viewGstin: {
    summary: 'View the GSTIN (Gateway)',
    description:
      'This api will fetch you all the GSTIN based state (approved: 1, pending: 2, delinked: 3, rejected: 4, all: 0). You can pass from and to date as optional parameter',
  },
  updateGstinStatus: {
    summary: 'Update the GSTIN status (Gateway)',
    description:
      'This api is used to update GSTIN status. Rule is to be passed when GSTIN status moves to pending (2) state',
  },
  removeGstin: {
    summary: 'Remove the GSTIN (Gateway)',
    description: 'This api is used soft delete GSTIN from DB',
  },
  sendReminder: {
    summary: 'Api send reminder for pending GSTIN (Gateway)',
    description: 'send reminder to checkers for approval',
  },
  sendOtp: {
    summary: 'Send OTP (Gateway)',
    description: 'Api used to send otp to user',
  },
  validateOtp: {
    summary: 'Validate OTP (Gateway)',
    description: 'Api used to validate otp to user',
  },
  getGstin: {
    summary: 'Get GSTIN for register GSTIN screen (Gateway)',
    description:
      "Get GSTIN for initial load and for discover GSTIN based on property value of discover = '1'",
  },
  addToMaster: {
    summary: 'Add GSTIN to master list (Gateway)',
    description: 'Add GSTIN to master with the rule specified by maker',
  },
  checkerGstin: {
    summary: 'Fetch pending GSTIN list for checker (Gateway)',
    description: 'Fetch pending GSTIN list for checker',
  },
  validateGstin: {
    summary: 'Validate whether GSTIN is available in DB (Gateway)',
    description: 'validate whether GSTIN is available in DB',
  },
  checkerGstinAction: {
    summary:
      'Checker Take action [approve/reject] on pending GSTIN list (Gateway)',
    description: 'Checker Take action [approve/reject] on pending GSTIN list',
  },
  epfoTransation: {
    summary: 'View the EPFO Challan Detail (Gateway)',
    description: 'This api will fetch you the EPFO Challan detail',
  },
  esicTransation: {
    summary: 'View the ESIC Challan Detail (Gateway)',
    description: 'This api will fetch you the ESIC Challan detail',
  },
  esicLogin: {
    summary: 'Login DEH API for ESIC (Gateway)',
    description: 'This API will fetch decrypted response data for challan details',
  },
  esicEncryption: {
    summary: 'ESIC encryption API (Gateway)',
    description: 'This API will fetch encrypted response data for challan details',
  },
  esicInitiateTransation: {
    summary: 'Initiate the ESIC transaction (Gateway)',
    description: 'Initiate the ESIC transaction',
  },
  esicCheckerAction: {
    summary: 'Approve / Reject Esic Challan (Gateway)',
    description: 'This API use for Approve / Reject Esic Challan.',
  },
  esicPostback: {
    summary: 'Generate postback data for ESIC portal (Gateway)',
    description: 'Generate postback data for ESIC portal.',
  },
  epfoAddDraft: {
    summary: 'Add or Edit EPFO Draft (Gateway)',
    description: 'This api will add or edit the EPFO draft',
  },
  epfoRaiseRequest: {
    summary: 'Raise the EPFO Challan Detail Request (Gateway)',
    description: 'This api will initiate the EPFO Challan request',
  },
  validateChequeNumber: {
    summary: 'Validate Cheque Number (Gateway)',
    description: 'This API will validate the cheque number from downstream',
  },
  epfoPendingApproval: {
    summary: 'View the EPFO Pending Approval Details(Gateway)',
    description: 'This api will fetch the Pending Approval Details',
  },
  myAccountList: {
    summary: 'Fetch list of accounts associated to Positive Pay (Gateway)',
    description: 'This API will fetch the list of Positive Pay accounts',
  },
  requestAction: {
    summary: 'This API is used to take action on submited cheque request',
    description: 'This API is used to take action on submited cheque request',
  },
  epfoApproveRejectRequest: {
    summary: 'Approve/Reject epfo challans (Gateway)',
    description: 'Approve/Reject epfo challans (Gateway)',
  },
  ppRequestInitiate: {
    summary: 'Request Initiate (Gateway)',
    description: 'This API will initiate Positive Pay cheque request',
  },
  ppFetchRecentRequestList: {
    summary: 'Fetch Recent Request List (Gateway)',
    description: 'This API will fetch recent positive pay request',
  },
  ppGenerateReport: {
    summary: 'Generate Report (Gateway)',
    description: 'This API will generate positive pay request report',
  },
  epfoLogin: {
    summary: 'EPFO Login API for decryption (Gateway)',
    description: 'It will decrypt the request data and return the plain text in the response'
  },
  epfoPostback: {
    summary: 'Generate postback data for EPFO portal (Gateway)',
    description: 'Generate postback data for EPFO portal.',
  },
  
};
