import { DocumentBuilder } from '@nestjs/swagger';

export const swaggerOptions = new DocumentBuilder()
  .setTitle('Corporate Omnichannel System Microservice')
  .setDescription('APIs to interact with the microservices')
  .setVersion('1.0')
  .addTag('bms')
  .build();
