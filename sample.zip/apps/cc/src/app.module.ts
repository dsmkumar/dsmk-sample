import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { OmsModule } from './grpc-client/oms.module';
import { OnboardModule } from './onboard/onboard.module';
import { LoggerModule } from '../../../shared/utility/logger/logger.module';
import { ModuleInit, AppServiceShutdown } from './app.service';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { BullModule } from '@nestjs/bull';
import { AuthInterceptor } from './auth.interceptor';
import { ConfigService } from '@nestjs/config';
import { QueuecallsService } from './queueCalls.service';

const redisConfigData = configService => ({
  host: configService.get('REDIS_HOST'),
  port: +configService.get('REDIS_PORT'),
});
@Module({
  imports: [
    ConfigModule.forRoot(),
    OmsModule,
    OnboardModule,
    LoggerModule,
    ModuleInit,
    AppServiceShutdown,
    BullModule.registerQueueAsync(
      {
        name: 'notification_sms',
        imports: [ConfigModule],
        useFactory: async (configService: ConfigService) => ({
          redis: redisConfigData(configService),
          defaultJobOptions: {
            removeOnComplete: true,
            removeOnFail: true,
          },
        }),
        inject: [ConfigService],
      },
      {
        name: 'notification_email',
        imports: [ConfigModule],
        useFactory: async (configService: ConfigService) => ({
          redis: redisConfigData(configService),
          defaultJobOptions: {
            removeOnComplete: true,
            removeOnFail: true,
          },
        }),
        inject: [ConfigService],
      },
      {
        name: 'downstream_logs',
        imports: [ConfigModule],
        useFactory: async (configService: ConfigService) => ({
          redis: redisConfigData(configService),
          defaultJobOptions: {
            removeOnComplete: true,
            removeOnFail: true,
          },
        }),
        inject: [ConfigService],
      },
    ),
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_INTERCEPTOR,
      useClass: AuthInterceptor,
    },
    QueuecallsService,
    QueuecallsService,
  ],
})
export class AppModule {}
