import { Module } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { join } from 'path';
import { OmsService } from './oms.service';
const config = require('config');
const url = config.get('url');
@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'oms',
        transport: Transport.GRPC,
        options: {
          package: 'oms',
          protoPath: join(
            __dirname,
            '../../apps/coc-client-gateway/proto/oms.proto',
          ),
          url: url.oms,
          loader: { keepCase: true, arrays: true, objects: true },
        },
      },
    ]),
  ],
  providers: [OmsService],
  exports: [OmsService],
})
export class OmsModule {}
