import { Inject, Injectable } from '@nestjs/common';
import { ClientGrpc } from '@nestjs/microservices';
import { Observable } from 'rxjs';
import {
  AddAggregatorRequestDto,
  DeleteAggregatorRequestDto,
  UpdateAggregatorRequestDto,
  GetAggreagatorRequestDto,
} from '../../../onboard/src/dto/aggregator.dto';

interface OmsGrpcServicesInterface {
  getHello(request): Observable<any>;
  getAggregators(request): Observable<any>;
  getAggregatorById(
    getAggreagatorRequestDto: GetAggreagatorRequestDto,
  ): Observable<any>;
  addAggregator(
    addAggregatorRequestDto: AddAggregatorRequestDto,
  ): Observable<any>;
  updateAggregator(
    updateAggregatorRequestDto: UpdateAggregatorRequestDto,
  ): Observable<any>;
  deleteAggregator(
    deleteAggregatorRequestDto: DeleteAggregatorRequestDto,
  ): Observable<any>;
}

@Injectable()
export class OmsService {
  private OmsGrpcService: OmsGrpcServicesInterface;

  constructor(@Inject('oms') private omsClient: ClientGrpc) {}

  onModuleInit() {
    this.OmsGrpcService =
      this.omsClient.getService<OmsGrpcServicesInterface>('OmsService');
  }

  getHello(): Promise<any> {
    return this.OmsGrpcService.getHello({}).toPromise();
  }

  getAggregators(): Promise<any> {
    return this.OmsGrpcService.getAggregators({}).toPromise();
  }

  getAggregatorById(
    getAggreagatorRequestDto: GetAggreagatorRequestDto,
  ): Promise<any> {
    return this.OmsGrpcService.getAggregatorById(
      getAggreagatorRequestDto,
    ).toPromise();
  }

  addAggregator(
    addAggregatorRequestDto: AddAggregatorRequestDto,
  ): Promise<any> {
    return this.OmsGrpcService.addAggregator(
      addAggregatorRequestDto,
    ).toPromise();
  }

  updateAggregator(
    updateAggregatorRequestDto: UpdateAggregatorRequestDto,
  ): Promise<any> {
    return this.OmsGrpcService.updateAggregator(
      updateAggregatorRequestDto,
    ).toPromise();
  }
  deleteAggregator(
    deleteAggregatorRequestDto: DeleteAggregatorRequestDto,
  ): Promise<any> {
    return this.OmsGrpcService.deleteAggregator(
      deleteAggregatorRequestDto,
    ).toPromise();
  }
}
