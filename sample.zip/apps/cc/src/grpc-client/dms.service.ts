import { Inject, Injectable } from '@nestjs/common';
import { ClientGrpc } from '@nestjs/microservices';
import { Observable } from 'rxjs';
import {
  GetQuickLinksResponseDto,
  GetUseridRequestDto,
  GetEditQuickLinksRequestDto,
  GetEditQuickLinksResponseDto,
  GetAccountMiniStatementsRequestDto,
  GetAccountMiniStatementsResponseDto,
  GetAccountBasicDetailsRequestDto,
  GetAccountBasicDetailsResponseDto,
  GetLimitsDetailsRequestDTO,
  GetLimitsDetailsResponseDTO,
  GetLoansDetailsRequestDTO,
  GetLoansDetailsResponseDTO,
  DownloadLoanOverviewRequestDto,
} from '../dashboard/dto/dashboard.dto';
import {
  AddTaskRequestDto,
  DeleteTaskRequestDto,
  AddHolidayRequestDto,
  DeleteHolidayRequestDto,
  DefaultRequestDto,
  GetUpcomingActivitiesRequestDto,
} from '../dashboard/dto/upcomingactivity.dto';
import {
  EditPinnedAccountsRequestDto,
  EditPinnedAccountResponseDto,
  GetAccountDetailsRequestDto,
  GetAccountDetailsResponseDto,
  FetchUserAccountDetailsRequestDto,
  FetchUserAccountDetailsResponseDto,
  DownloadAccountOverviewRequestDto,
} from '../dashboard/dto/accountDetails.dto';
import {
  GetRecentActivitiesRequestDto,
  RemindApproversRequestDto,
} from '../dashboard/dto/recentActivity.dto';

interface DmsGrpcServicesInterface {
  getHello(request): Observable<any>;
  getQuickLinks(request: GetUseridRequestDto): Observable<any>;
  getUserid(request: GetUseridRequestDto): Observable<any>;
  addTask(AddTaskRequestDto: AddTaskRequestDto): Observable<any>;
  deleteTask(DeleteTaskRequestDto: DeleteTaskRequestDto): Observable<any>;
  getAllTasks(DefaultRequestDto: DefaultRequestDto): Observable<any>;
  editQuickLinks(
    getEditQuickLinksRequestDto: GetEditQuickLinksRequestDto,
  ): Observable<any>;
  editPinnedAccounts(
    EditPinnedAccountsRequestDto: EditPinnedAccountsRequestDto,
  ): Observable<any>;
  getAccountDetails(
    GetAccountDetails: GetAccountDetailsRequestDto,
  ): Observable<any>;
  downloadAccountOverview(
    downloadAccountOverviewRequestDto: DownloadAccountOverviewRequestDto,
  ): Observable<any>;
  addHoliday(AddHolidayRequestDto: AddHolidayRequestDto): Observable<any>;
  deleteHoliday(
    DeleteHolidayRequestDto: DeleteHolidayRequestDto,
  ): Observable<any>;
  getAllHolidays(DefaultRequestDto: DefaultRequestDto): Observable<any>;
  getUpcomingActivities(
    getUpcomingActivitiesRequestDto: GetUpcomingActivitiesRequestDto,
  ): Observable<any>;
  getAccountMiniStatements(
    request: GetAccountMiniStatementsRequestDto,
  ): Observable<any>;
  getRecentActivities(
    getRecentActivitiesRequestDto: GetRecentActivitiesRequestDto,
  ): Observable<any>;
  remindApprovers(
    remindApproversRequestDto: RemindApproversRequestDto,
  ): Observable<any>;
  getAccountBasicDetails(
    request: GetAccountBasicDetailsRequestDto,
  ): Observable<any>;

  approveRejectDue(request: any): Observable<any>;

  getLimitsDetails(
    request: GetLimitsDetailsRequestDTO,
  ): Observable<GetLimitsDetailsResponseDTO>;
  getLoansDetails(
    request: GetLoansDetailsRequestDTO,
  ): Observable<GetLoansDetailsResponseDTO>;
  downloadLoanOverview(
    downloadLoanOverviewRequestDto: DownloadLoanOverviewRequestDto,
  ): Observable<any>;
}

@Injectable()
export class DmsService {
  private DmsGrpcService: DmsGrpcServicesInterface;

  constructor(@Inject('dms') private dmsClient: ClientGrpc) {}

  onModuleInit() {
    this.DmsGrpcService =
      this.dmsClient.getService<DmsGrpcServicesInterface>('DmsService');
  }

  getHello(): Promise<any> {
    return this.DmsGrpcService.getHello({}).toPromise();
  }

  async getQuickLinks(
    request: GetUseridRequestDto,
  ): Promise<GetQuickLinksResponseDto> {
    return this.DmsGrpcService.getQuickLinks(request).toPromise();
  }

  async editQuickLinks(
    request: GetEditQuickLinksRequestDto,
  ): Promise<GetEditQuickLinksResponseDto> {
    return this.DmsGrpcService.editQuickLinks(request).toPromise();
  }

  async addTask(
    addTaskRequestDto: AddTaskRequestDto,
  ): Promise<AddTaskRequestDto> {
    return this.DmsGrpcService.addTask(addTaskRequestDto).toPromise();
  }

  async deleteTask(deleteTaskRequestDto: DeleteTaskRequestDto): Promise<any> {
    return this.DmsGrpcService.deleteTask(deleteTaskRequestDto).toPromise();
  }

  async getAllTasks(
    defaultRequestDto: DefaultRequestDto,
  ): Promise<DefaultRequestDto> {
    return this.DmsGrpcService.getAllTasks(defaultRequestDto).toPromise();
  }

  async addHoliday(
    addHolidayRequestDto: AddHolidayRequestDto,
  ): Promise<AddHolidayRequestDto> {
    return this.DmsGrpcService.addHoliday(addHolidayRequestDto).toPromise();
  }

  async deleteHoliday(
    deleteHolidayRequestDto: DeleteHolidayRequestDto,
  ): Promise<any> {
    return this.DmsGrpcService.deleteHoliday(
      deleteHolidayRequestDto,
    ).toPromise();
  }

  async getAllHolidays(
    defaultRequestDto: DefaultRequestDto,
  ): Promise<DefaultRequestDto> {
    return this.DmsGrpcService.getAllHolidays(defaultRequestDto).toPromise();
  }

  async getUpcomingActivities(
    getUpcomingActivitiesRequestDto: GetUpcomingActivitiesRequestDto,
  ): Promise<DefaultRequestDto> {
    return this.DmsGrpcService.getUpcomingActivities(
      getUpcomingActivitiesRequestDto,
    ).toPromise();
  }

  async editPinnedAccounts(
    data: EditPinnedAccountsRequestDto,
  ): Promise<EditPinnedAccountResponseDto> {
    return this.DmsGrpcService.editPinnedAccounts(data).toPromise();
  }

  async getAccountDetails(
    data: GetAccountDetailsRequestDto,
  ): Promise<GetAccountDetailsResponseDto> {
    return this.DmsGrpcService.getAccountDetails(data).toPromise();
  }

  async downloadAccountOverview(
    downloadAccountOverviewRequestDto: DownloadAccountOverviewRequestDto,
  ): Promise<GetAccountDetailsResponseDto> {
    return this.DmsGrpcService.downloadAccountOverview(
      downloadAccountOverviewRequestDto,
    ).toPromise();
  }

  async getAccountMiniStatements(
    request: GetAccountMiniStatementsRequestDto,
  ): Promise<GetAccountMiniStatementsResponseDto> {
    return this.DmsGrpcService.getAccountMiniStatements(request).toPromise();
  }

  async getRecentActivities(
    getRecentActivitiesRequestDto: GetRecentActivitiesRequestDto,
  ): Promise<any> {
    return this.DmsGrpcService.getRecentActivities(
      getRecentActivitiesRequestDto,
    ).toPromise();
  }

  async remindApprovers(
    remindApproversRequestDto: RemindApproversRequestDto,
  ): Promise<any> {
    return this.DmsGrpcService.remindApprovers(
      remindApproversRequestDto,
    ).toPromise();
  }
  async getAccountBasicDetails(
    request: GetAccountBasicDetailsRequestDto,
  ): Promise<GetAccountBasicDetailsResponseDto> {
    return this.DmsGrpcService.getAccountBasicDetails(request).toPromise();
  }

  async approveRejectDue(request: any): Promise<any> {
    return this.DmsGrpcService.approveRejectDue(request).toPromise();
  }

  async getLimitsDetails(
    request: GetLimitsDetailsRequestDTO,
  ): Promise<GetLimitsDetailsResponseDTO> {
    return this.DmsGrpcService.getLimitsDetails(request).toPromise();
  }
  async getLoansDetails(
    request: GetLoansDetailsRequestDTO,
  ): Promise<GetLoansDetailsResponseDTO> {
    return this.DmsGrpcService.getLoansDetails(request).toPromise();
  }

  async downloadLoanOverview(
    downloadLoanOverviewRequestDto: DownloadLoanOverviewRequestDto,
  ): Promise<GetLoansDetailsResponseDTO> {
    return this.DmsGrpcService.downloadLoanOverview(
      downloadLoanOverviewRequestDto,
    ).toPromise();
  }
}
