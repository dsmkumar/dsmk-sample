import { Module } from '@nestjs/common';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { join } from 'path';
import { DmsService } from './dms.service';
const config = require('config');
const url = config.get('url');
@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'dms',
        transport: Transport.GRPC,
        options: {
          package: 'dms',
          protoPath: join(
            __dirname,
            '../../apps/coc-client-gateway/proto/dms.proto',
          ),
          url: url.dms,
          loader: { keepCase: true, arrays: true, objects: true },
        },
      },
    ]),
  ],
  providers: [DmsService],
  exports: [DmsService],
})
export class DmsModule {}
