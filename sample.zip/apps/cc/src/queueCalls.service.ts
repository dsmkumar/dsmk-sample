import { Injectable } from '@nestjs/common';
import {InjectQueue} from '@nestjs/bull';
import { Queue } from 'bull';

@Injectable()
export class QueuecallsService {
    constructor(
        @InjectQueue('downstream_logs')private dsQueue : Queue
    ) {}

    async postQueueCall(type, logData) {
        return await this.dsQueue.add(type, logData);        
    }
}
