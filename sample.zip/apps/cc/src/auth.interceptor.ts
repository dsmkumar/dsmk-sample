import {
  CallHandler,
  ExecutionContext,
  Inject,
  Injectable,
  NestInterceptor,
  Optional,
  UnauthorizedException,
} from '@nestjs/common';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { LoggerService } from '../../../shared/utility/logger/logger.service';

@Injectable()
export class AuthInterceptor implements NestInterceptor {
  private logger: LoggerService = new LoggerService('coc-auth-interceptor');
  constructor() {}
  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<any>> {
    const httpContext = context.switchToHttp();
    const req = httpContext.getRequest();

    const correlationId =
      req.headers && req.headers['x-fapi-uuid']
        ? req.headers['x-fapi-uuid']
        : 'externalApiCall';

    this.logger.log(correlationId, 'correlationId----', correlationId);
    this.logger.log(correlationId, 'url---', req.url);
    this.logger.log(
      correlationId,
      'DEPLOY_BASE_URL',
      process.env.DEPLOY_BASE_URL,
    );
    this.logger.log(correlationId, 'query---', req.query);
    this.logger.log(correlationId, 'body---', req.body);
    return next.handle();
  }

  parseJwt(token) {
    var base64Payload = token.split('.')[1];
    var payload = Buffer.from(base64Payload, 'base64');
    return JSON.parse(payload.toString());
  }
}
