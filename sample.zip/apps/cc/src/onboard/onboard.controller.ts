import {
  Body,
  Res,
  Controller,
  Get,
  HttpCode,
  Post,
  Delete,
  UseFilters,
  Put,
  Param,
} from '@nestjs/common';
import { OnboardService } from './onboard.service';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { HttpExceptionFilter } from 'shared/filters/http-exception.filter';
import {
  AddAggregatorRequestDto,
  DeleteAggregatorRequestDto,
  UpdateAggregatorRequestDto,
  GetAggreagatorRequestDto,
} from '../../../onboard/src/dto/aggregator.dto';

@ApiTags('Onboard')
@Controller('onboard')
@UseFilters(new HttpExceptionFilter())
export class OnboardController {
  constructor(private omsService: OnboardService) {}

  @Get('/get-hello')
  @ApiOperation({
    summary: 'Get Hello Message',
    description: 'To check if coc client-srm connection is working fine',
  })
  @ApiResponse({
    status: 201,
    description: 'To check if coc client-srm connection is working fine',
  })
  async getHello(): Promise<any> {
    console.log('coc');
    return this.omsService.getHello();
  }

  @Get('/aggregators')
  @ApiOperation({
    summary: 'Get Aggregators List',
    description: 'Get Aggregators List',
  })
  @ApiResponse({
    status: 201,
    description: 'Get Aggregators List',
  })
  async getAggregators(): Promise<any> {
    console.log('coc');
    return this.omsService.getAggregators();
  }
  @Get('/aggregator/:id')
  @ApiOperation({
    summary: 'Get Aggregator By Id',
    description: 'Get Aggregator By Id',
  })
  @ApiResponse({
    status: 201,
    description: 'Get Aggregator By Id',
  })
  async getAggregatorById(@Param() params): Promise<any> {
    console.log('coc', params);
    return this.omsService.getAggregatorById({ id: params['id'] });
  }
  @Post('/aggregator')
  @ApiOperation({
    summary: 'Add Aggregator',
    description: 'Add Aggregator',
  })
  @ApiResponse({
    status: 201,
    description: 'Add Aggregator',
  })
  async addAggregator(
    @Body() addAggregatorRequestDto: AddAggregatorRequestDto,
  ): Promise<any> {
    console.log('coc', addAggregatorRequestDto);
    return this.omsService.addAggregator(addAggregatorRequestDto);
  }
  @Put('/aggregator')
  @ApiOperation({
    summary: 'Update Aggregator',
    description: 'Update Aggregator',
  })
  @ApiResponse({
    status: 201,
    description: 'Update Aggregator',
  })
  async updateAggregator(
    @Body() updateAggregatorRequestDto: UpdateAggregatorRequestDto,
  ): Promise<any> {
    console.log('coc');
    return this.omsService.updateAggregator(updateAggregatorRequestDto);
  }
  @Post('/aggregator/delete')
  @ApiOperation({
    summary: 'Delete Aggregator',
    description: 'Delete Aggregator',
  })
  @ApiResponse({
    status: 201,
    description: 'Delete Aggregator',
  })
  async deleteAggregator(
    @Body() deleteAggregatorRequestDto: DeleteAggregatorRequestDto,
  ): Promise<any> {
    console.log('coc');
    return this.omsService.deleteAggregator(deleteAggregatorRequestDto);
  }
}
