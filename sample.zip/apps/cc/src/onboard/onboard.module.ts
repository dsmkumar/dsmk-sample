import { Module } from '@nestjs/common';
import { OmsModule } from '../grpc-client/oms.module';
import { OnboardController } from './onboard.controller';
import { OnboardService } from './onboard.service';
import { BullModule } from '@nestjs/bull';
import { ConfigModule, ConfigService } from '@nestjs/config';

const redisConfigData = configService => ({
  host: configService.get('REDIS_HOST'),
  port: +configService.get('REDIS_PORT'),
});
@Module({
  imports: [
    OmsModule,

    ConfigModule,
    BullModule.registerQueueAsync(
      {
        name: 'notification_sms',
        imports: [ConfigModule],
        useFactory: async (configService: ConfigService) => ({
          redis: redisConfigData(configService),
          defaultJobOptions: {
            removeOnComplete: true,
            removeOnFail: true,
          },
        }),
        inject: [ConfigService],
      },
      {
        name: 'notification_email',
        imports: [ConfigModule],
        useFactory: async (configService: ConfigService) => ({
          redis: redisConfigData(configService),
          defaultJobOptions: {
            removeOnComplete: true,
            removeOnFail: true,
          },
        }),
        inject: [ConfigService],
      },
    ),
  ],
  controllers: [OnboardController],
  providers: [OnboardService],
})
export class OnboardModule {}
