import { Injectable } from '@nestjs/common';
import { RpcException } from '@nestjs/microservices';
import { OmsService } from '../grpc-client/oms.service';
import {
  AddAggregatorRequestDto,
  DeleteAggregatorRequestDto,
  UpdateAggregatorRequestDto,
  GetAggreagatorRequestDto,
} from '../../../onboard/src/dto/aggregator.dto';
import { LoggerService } from 'shared/utility/logger/logger.service';

@Injectable()
export class OnboardService {
  private readonly logger: LoggerService = new LoggerService(
    OnboardService.name,
  );
  constructor(private omsService: OmsService) {}

  getHello(): Promise<any> {
    console.log('till service');
    return this.omsService.getHello();
  }
  getAggregators(): Promise<any> {
    console.log('till service');
    return this.omsService.getAggregators();
  }
  getAggregatorById(
    getAggreagatorRequestDto: GetAggreagatorRequestDto,
  ): Promise<any> {
    console.log('till service');
    return this.omsService.getAggregatorById(getAggreagatorRequestDto);
  }
  addAggregator(
    addAggregatorRequestDto: AddAggregatorRequestDto,
  ): Promise<any> {
    console.log('till service');
    return this.omsService.addAggregator(addAggregatorRequestDto);
  }
  updateAggregator(
    updateAggregatorRequestDto: UpdateAggregatorRequestDto,
  ): Promise<any> {
    console.log('till service');
    if (updateAggregatorRequestDto.id) {
      return this.omsService.updateAggregator(updateAggregatorRequestDto);
    } else {
      return Promise.resolve({ status: 500, message: 'ID is required' });
    }
  }
  deleteAggregator(
    deleteAggregatorRequestDto: DeleteAggregatorRequestDto,
  ): Promise<any> {
    console.log('till service');
    return this.omsService.deleteAggregator(deleteAggregatorRequestDto);
  }
}
