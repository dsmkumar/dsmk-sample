import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { SwaggerModule } from '@nestjs/swagger';
import { LoggerService } from '../../../shared/utility/logger/logger.service';
import { ValidationPipe } from '@nestjs/common';
const cors = require('cors');

async function bootstrap() {
  const port = 9090;
  const app = await NestFactory.create(AppModule, {
    logger: new LoggerService('Main'),
  });
  app.use(cors());
  app.useGlobalPipes(new ValidationPipe());

  const logger = app.get(LoggerService);
  app.useLogger(new LoggerService('Main'));
  const server = await app.listen(port, () => {
    logger.log(`Client listening on port ${port}`);
  });

  app.enableShutdownHooks();

  process.on('SIGTERM', () => {
    server.close();
  });

  process.on('SIGINT', () => {
    server.close();
  });
}
bootstrap();
