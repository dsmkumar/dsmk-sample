import { Injectable, OnModuleInit, OnApplicationShutdown, OnModuleDestroy, OnApplicationBootstrap, BeforeApplicationShutdown } from '@nestjs/common';
import { LoggerService } from '../../../shared/utility/logger/logger.service';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }
}

@Injectable()
export class ModuleInit implements OnModuleInit {
  private logger: LoggerService = new LoggerService('coc-app-service');
  onModuleInit() {
    this.logger.log(`The module has been initialized.`);
  }
}

@Injectable()
export class AppServiceShutdown implements OnApplicationShutdown {
  private logger: LoggerService = new LoggerService('coc-app-service');
  onApplicationShutdown(signal: string) {
    this.logger.log(signal);
  }
}
